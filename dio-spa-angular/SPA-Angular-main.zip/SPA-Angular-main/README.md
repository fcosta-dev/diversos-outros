# SPA-Angular
Desenvolvendo SPA com Angular.
